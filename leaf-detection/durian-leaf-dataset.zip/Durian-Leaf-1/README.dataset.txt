# Durian Leaf > 2022-06-09 9:10pm
https://universe.roboflow.com/yottsu/durian-leaf

Provided by a Roboflow user
License: CC BY 4.0

