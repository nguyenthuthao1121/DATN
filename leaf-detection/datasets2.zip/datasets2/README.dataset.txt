# My First Project > 2025-04-12 10:09pm
https://universe.roboflow.com/leaf-detection-xo4vh/my-first-project-ctpta

Provided by a Roboflow user
License: CC BY 4.0

